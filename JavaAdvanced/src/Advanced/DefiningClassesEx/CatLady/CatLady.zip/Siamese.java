package Advanced.DefiningClassesEx.CatLady;

public class Siamese extends Cat{

    Siamese(String name, double size) {
        super("Siamese", name, size);
    }
}
