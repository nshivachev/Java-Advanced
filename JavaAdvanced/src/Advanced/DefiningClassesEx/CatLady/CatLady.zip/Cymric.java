package Advanced.DefiningClassesEx.CatLady;

public class Cymric extends Cat{

    Cymric(String name, double size) {
        super("Cymric", name, size);    }
}
