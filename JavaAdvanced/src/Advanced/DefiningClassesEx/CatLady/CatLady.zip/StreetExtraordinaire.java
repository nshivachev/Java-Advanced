package Advanced.DefiningClassesEx.CatLady;

public class StreetExtraordinaire extends Cat{

    StreetExtraordinaire(String name, double size) {
        super("StreetExtraordinaire", name, size);
    }
}
